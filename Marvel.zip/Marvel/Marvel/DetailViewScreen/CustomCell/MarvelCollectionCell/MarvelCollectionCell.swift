//
//  MarvelCollectionCell.swift
//  Marvel
//
//  Created by Mayur Rangari on 10/03/22.
//

import UIKit

class MarvelCollectionCell: UICollectionViewCell {

    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblIssueNo: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
